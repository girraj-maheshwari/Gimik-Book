String stripCodeFences(String raw) {
  var s = raw.trim();
  if (s.startsWith('```') && s.endsWith('```')) {
    s = s.substring(3, s.length - 3).trim();
  }
  return s;
}
