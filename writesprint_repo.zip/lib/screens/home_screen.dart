import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:writesprint/services/repository.dart';
import 'package:writesprint/models/daily_lesson.dart';
import 'package:writesprint/screens/lesson_screen.dart';
import 'package:writesprint/services/progress_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  DailyLesson? lesson;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _loadLesson();
  }

  Future<void> _loadLesson() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final repo = Provider.of<Repository>(context, listen: false);
      final l = await repo.getLessonForToday();
      setState(() {
        lesson = l;
        loading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final progress = Provider.of<ProgressService>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('WriteSprint')),
      body: loading
          ? const Center(child: CircularProgressIndicator())
          : error != null
              ? Center(child: Text('Error: $error'))
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Text(lesson!.title, style: Theme.of(context).textTheme.headlineSmall),
                      const SizedBox(height: 8),
                      Text('Topic: ${lesson!.topic} • Difficulty: ${lesson!.difficulty}'),
                      const SizedBox(height: 12),
                      Text(lesson!.reading.text, maxLines: 3, overflow: TextOverflow.ellipsis),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(builder: (_) => LessonScreen(lesson: lesson!)));
                        },
                        child: const Text('Start Today\'s Lesson'),
                      ),
                      const Spacer(),
                      Text('XP: ${progress.xp}    Streak: ${progress.streak}'),
                      const SizedBox(height: 8),
                      OutlinedButton(onPressed: _loadLesson, child: const Text('Refresh / Force Fetch')),
                    ],
                  ),
                ),
    );
  }
}
