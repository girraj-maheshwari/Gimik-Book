import 'package:flutter/material.dart';
import 'package:writesprint/models/daily_lesson.dart';
import 'exercise_screen.dart';
import 'package:provider/provider.dart';
import 'package:writesprint/services/progress_service.dart';

class LessonScreen extends StatelessWidget {
  final DailyLesson lesson;
  const LessonScreen({required this.lesson, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final progress = Provider.of<ProgressService>(context);
    return Scaffold(
      appBar: AppBar(title: Text(lesson.title)),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Reading', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          Text(lesson.reading.text),
          const SizedBox(height: 12),
          ...lesson.reading.highlights.map((h) => Padding(padding: const EdgeInsets.only(bottom:6), child: Text('• $h'))),
          const Divider(),
          Text('Exercises', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          ...lesson.exercises.map((ex) => Card(
            child: ListTile(
              title: Text(ex.type.toUpperCase()),
              subtitle: Text(ex.prompt, maxLines: 2, overflow: TextOverflow.ellipsis),
              trailing: const Icon(Icons.play_arrow),
              onTap: () async {
                final got = await Navigator.of(context).push(MaterialPageRoute(builder: (_) => ExerciseScreen(exercise: ex)));
                if (got == true) {
                  progress.addXp(10);
                }
              },
            ),
          )),
          const SizedBox(height: 12),
          Center(
            child: ElevatedButton(
              onPressed: () {
                progress.addXp(50);
                progress.bumpStreak();
                ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lesson complete! +50 XP')));
                Navigator.of(context).pop();
              },
              child: const Text('Finish Lesson'),
            ),
          )
        ]),
      ),
    );
  }
}
