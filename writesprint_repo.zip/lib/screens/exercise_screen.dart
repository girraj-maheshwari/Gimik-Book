import 'package:flutter/material.dart';
import 'package:writesprint/models/daily_lesson.dart';

class ExerciseScreen extends StatefulWidget {
  final Exercise exercise;
  const ExerciseScreen({required this.exercise, Key? key}) : super(key: key);

  @override
  State<ExerciseScreen> createState() => _ExerciseScreenState();
}

class _ExerciseScreenState extends State<ExerciseScreen> {
  final TextEditingController _ctrl = TextEditingController();
  String? feedback;
  bool accepted = false;
  int? selectedMcq;

  @override
  Widget build(BuildContext context) {
    final ex = widget.exercise;
    return Scaffold(
      appBar: AppBar(title: Text(ex.type.toUpperCase())),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          Text(ex.prompt),
          const SizedBox(height: 12),
          if (ex.type == 'mcq' && ex.meta['options'] != null)
            ..._buildMcq(ex)
          else
            TextField(controller: _ctrl, maxLines: 5, decoration: const InputDecoration(border: OutlineInputBorder())),
          const SizedBox(height: 12),
          ElevatedButton(
            onPressed: () {
              _submit();
            },
            child: const Text('Submit'),
          ),
          if (feedback != null) Padding(padding: const EdgeInsets.only(top:12), child: Text(feedback!)),
        ]),
      ),
    );
  }

  List<Widget> _buildMcq(Exercise ex) {
    final opts = (ex.meta['options'] as List<dynamic>).map((e) => e.toString()).toList();
    return opts.asMap().entries.map((entry) {
      final idx = entry.key;
      final text = entry.value;
      return ListTile(
        title: Text(text),
        leading: Radio<int>(
          value: idx,
          groupValue: selectedMcq,
          onChanged: (v) {
            setState(() {
              selectedMcq = v;
            });
          },
        ),
      );
    }).toList();
  }

  void _submit() {
    final ex = widget.exercise;
    final input = _ctrl.text.trim();
    if (ex.type == 'mcq') {
      final correct = ex.meta['correct'] ?? 0;
      final isCorrect = (selectedMcq != null && selectedMcq == correct);
      setState(() {
        feedback = isCorrect ? 'Correct! +10 XP' : 'Not quite. Try to explain why.';
      });
      Future.delayed(const Duration(milliseconds: 700), () {
        Navigator.of(context).pop(isCorrect);
      });
      return;
    }

    if (input.isEmpty) {
      setState(() { feedback = 'Write something to submit.'; });
      return;
    }

    int score = 0;
    if (input.length < 100) score += 60;
    else score += 40;
    if (input.split(' ').length < 25) score += 20;
    else score += 10;

    final accept = score >= 70;
    setState(() {
      feedback = accept ? 'Nice. +10 XP' : 'Good attempt. Try to be shorter and clearer.';
    });

    Future.delayed(const Duration(milliseconds: 800), () {
      Navigator.of(context).pop(accept);
    });
  }
}
