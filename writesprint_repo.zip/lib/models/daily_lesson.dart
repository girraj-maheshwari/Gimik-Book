import 'package:hive/hive.dart';

part 'daily_lesson.g.dart';

@HiveType(typeId: 0)
class Exercise extends HiveObject {
  @HiveField(0)
  String id;
  @HiveField(1)
  String type; // hook|rewrite|mcq|edit
  @HiveField(2)
  String prompt;
  @HiveField(3)
  Map<String, dynamic> meta;

  Exercise({required this.id, required this.type, required this.prompt, Map<String, dynamic>? meta})
      : meta = meta ?? {};
}

@HiveType(typeId: 1)
class Reading extends HiveObject {
  @HiveField(0)
  String id;
  @HiveField(1)
  String text;
  @HiveField(2)
  List<String> highlights;

  Reading({required this.id, required this.text, required this.highlights});
}

@HiveType(typeId: 2)
class DailyLesson extends HiveObject {
  @HiveField(0)
  String date; // YYYY-MM-DD
  @HiveField(1)
  String topic;
  @HiveField(2)
  String title;
  @HiveField(3)
  Reading reading;
  @HiveField(4)
  List<Exercise> exercises;
  @HiveField(5)
  String difficulty;
  @HiveField(6)
  String? notes;

  DailyLesson({
    required this.date,
    required this.topic,
    required this.title,
    required this.reading,
    required this.exercises,
    required this.difficulty,
    this.notes,
  });
}
