import 'dart:convert';
import 'package:writesprint/models/daily_lesson.dart';
import 'package:writesprint/services/ai_service.dart';
import 'package:writesprint/services/hive_service.dart';

class Repository {
  final AiService ai;

  Repository({required this.ai});

  Future<DailyLesson> getLessonForToday() async {
    final today = DateTime.now();
    final key = _formatDate(today);
    final cached = HiveService.getLessonForDate(key);
    if (cached != null) return cached;

    final masterPrompt = _masterPrompt();
    final raw = await ai.generate(masterPrompt);

    final jsonStr = _extractJson(raw);
    final Map<String, dynamic> j = json.decode(jsonStr);

    final lesson = _fromMap(j);
    await HiveService.saveLesson(lesson);
    return lesson;
  }

  String _formatDate(DateTime d) => '${d.year.toString().padLeft(4,'0')}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';

  String _extractJson(String raw) {
    raw = raw.trim();
    if (raw.startsWith('```')) {
      raw = raw.replaceAll('```', '').trim();
    }
    final start = raw.indexOf('{');
    final end = raw.lastIndexOf('}');
    if (start != -1 && end != -1 && end > start) {
      return raw.substring(start, end + 1);
    }
    return raw;
  }

  String _masterPrompt() {
    return '''
You are "WriteSprint Content Generator". Produce ONE JSON object only. Do NOT add any explanation.

Constraints:
- Language: English.
- Keep reading length between 120 and 220 words.
- Use original text (do not copy any copyrighted sentence).
- Topic: pick a relevant content-writing micro-skill. Vary topics day-to-day (hooks, clarity, editing, headlines, email openers, tiny stories).
- Provide practical, concrete examples.
- Make exercises solvable within 30–90 seconds.

Output JSON schema:

{
  "date":"YYYY-MM-DD",
  "topic":"short-topic-slug",
  "title":"Short title, 4-8 words",
  "reading":{
     "id":"r1",
     "text":"... (120-220 words)",
     "highlights":["8-12 word highlight","...","..."]
  },
  "exercises":[
    {
      "id":"e1",
      "type":"hook|rewrite|mcq|edit",
      "prompt":"short prompt",
      "meta": {}
    }
  ],
  "difficulty":"easy|medium|hard",
  "notes":"optional short advice"
}

Make sure the JSON is valid. Keep fields exactly as specified. For mcq include meta.options (array) and meta.correct (integer, 0-based index).
''';
  }

  DailyLesson _fromMap(Map<String, dynamic> j) {
    final readingMap = j['reading'] as Map<String, dynamic>;
    final reading = Reading(
      id: readingMap['id'] ?? 'r1',
      text: readingMap['text'] ?? '',
      highlights: (readingMap['highlights'] as List<dynamic>?)?.map((e) => e.toString()).toList() ?? [],
    );

    final exercises = (j['exercises'] as List<dynamic>? ?? []).map((e) {
      final map = Map<String, dynamic>.from(e);
      return Exercise(
        id: map['id'] ?? '',
        type: map['type'] ?? 'rewrite',
        prompt: map['prompt'] ?? '',
        meta: map['meta'] != null ? Map<String, dynamic>.from(map['meta']) : {},
      );
    }).toList();

    return DailyLesson(
      date: j['date'] ?? _formatDate(DateTime.now()),
      topic: j['topic'] ?? 'general',
      title: j['title'] ?? 'Daily Lesson',
      reading: reading,
      exercises: exercises,
      difficulty: j['difficulty'] ?? 'easy',
      notes: j['notes'],
    );
  }
}
