import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter_dotenv/flutter_dotenv.dart';

class AiService {
  final String endpoint;
  final String apiKey;
  final String model;

  AiService({required this.endpoint, required this.apiKey, this.model = 'gpt-4o-mini'});

  /// Call model with prompt and return raw text.
  Future<String> generate(String prompt, {int maxTokens = 800}) async {
    final url = Uri.parse(endpoint);
    final body = jsonEncode({
      "model": model,
      "messages": [
        {"role": "system", "content": "You are a JSON-only generator for a learning app."},
        {"role": "user", "content": prompt}
      ],
      "max_tokens": maxTokens,
      "temperature": 0.2
    });

    final resp = await http.post(
      url,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer $apiKey',
      },
      body: body,
    );

    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      final j = jsonDecode(resp.body);
      final text = (j['choices']?[0]?['message']?['content']) ?? (j['choices']?[0]?['text']) ?? '';
      return text.toString();
    } else {
      throw Exception('AI error: ${resp.statusCode}: ${resp.body}');
    }
  }

  static Future<AiService> fromEnv() async {
    await dotenv.load();
    final apiKey = dotenv.env['OPENAI_API_KEY'] ?? '';
    final endpoint = dotenv.env['OPENAI_ENDPOINT'] ?? 'https://api.openai.com/v1/chat/completions';
    final model = dotenv.env['OPENAI_MODEL'] ?? 'gpt-4o-mini';
    return AiService(endpoint: endpoint, apiKey: apiKey, model: model);
  }
}
