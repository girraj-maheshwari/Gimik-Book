import 'package:hive_flutter/hive_flutter.dart';
import 'package:writesprint/models/daily_lesson.dart';

class HiveService {
  static const String lessonBox = 'lessons_v1';

  static Future<void> init() async {
    await Hive.initFlutter();
    Hive.registerAdapter(ExerciseAdapter());
    Hive.registerAdapter(ReadingAdapter());
    Hive.registerAdapter(DailyLessonAdapter());
    await Hive.openBox<DailyLesson>(lessonBox);
  }

  static Box<DailyLesson> lessonBoxInstance() => Hive.box<DailyLesson>(lessonBox);

  static DailyLesson? getLessonForDate(String yyyyMMdd) {
    return lessonBoxInstance().get(yyyyMMdd);
  }

  static Future<void> saveLesson(DailyLesson lesson) async {
    await lessonBoxInstance().put(lesson.date, lesson);
  }
}
