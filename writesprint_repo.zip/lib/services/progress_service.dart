import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ProgressService extends ChangeNotifier {
  int xp = 0;
  int streak = 0;
  SharedPreferences? _prefs;

  Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
    xp = _prefs?.getInt('xp') ?? 0;
    streak = _prefs?.getInt('streak') ?? 0;
  }

  void addXp(int amount) {
    xp += amount;
    _prefs?.setInt('xp', xp);
    notifyListeners();
  }

  void bumpStreak() {
    streak += 1;
    _prefs?.setInt('streak', streak);
    notifyListeners();
  }

  void resetStreak() {
    streak = 0;
    _prefs?.setInt('streak', streak);
    notifyListeners();
  }
}
